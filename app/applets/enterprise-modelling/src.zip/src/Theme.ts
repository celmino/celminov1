import { UITemplate } from '@tuval/forms';

export const theme = new UITemplate();