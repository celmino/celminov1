
import { useSessionService } from "@realmocean/services";
import { HStack, Spinner, UIDataTable, WorkProtocol, useDialog, useProtocol, Text, useNavigate, cLeading, SortableListView, VStack, ReactView } from "@tuval/forms";
import BoardSectionList from "../views/components/BoardSectionList";
import React from "react";
import { MultipleContainers } from "../views/components/MultipleContainers";

const statuses = [
    {
        id: '1',
        title: 'To Do',
        stageId: '1'
    },
    {
        id: '2',
        title: 'In Progress',
        stageId: '1'
    },
    {
        id: '3',
        title: 'Done',
        stageId: '1'
    }
]

const stages = [
    {
        id: "1",
        status_name: "Active Statuses",
        status_background_color: "",
        status_color: ""
    },
    {
        id: "2",
        status_name: "Done Statuses",
        status_background_color: "",
        status_color: ""
    }
]

export const ListStatusWidget = (fieldInfo: any) => {
    /* const dialog = useDialog();
    const navigate = useNavigate();

    const { columns, resource, filter, sort } = fieldInfo;
    const { getList } = useProtocol(WorkProtocol);
    const { data: workspaces, isLoading } = getList('workspaces', {
        filter: {
            tenant_id: useSessionService().TenantId
        }
    }) */


    return (
        VStack(
            ReactView(
                <MultipleContainers  items={{
                    "A": [
                        {
                            id: '1',
                            title: 'To Do',
                            stageId: '1'
                        },
                        {
                            id: '2',
                            title: 'In Progress',
                            stageId: '1'
                        },
                        {
                            id: '3',
                            title: 'Done',
                            stageId: '1'
                        }
                    ],
                }} vertical template={(args) => {
                    return VStack(
                        Text(args.value.title)
                    ).height(32).background('white')
                }} />
            ).frame(true).width('100%')
        )
    )
}