import {
    BrokerContext, Button,
    EditableHeader,
    Fragment,
    HStack, Heading, Icon, Icons, MenuButton, Spacer, Spinner, State, TabList, TaskProtocol,
    Text, TextField, UIFormController, UINavigate, UIRouteOutlet, UIView, UIWidget, VDivider, VStack, SvgIcon,
    WorkProtocol,
    cBottomLeading, cHorizontal, cLeading, cTopLeading, getAppFullName, useNavigate, useParams, useProtocol, useState, List
} from "@tuval/forms";
import { SelectViewDialog } from "./dialogs/SelectViewDialog";
import { WorkbenchIcons } from "./AppletIcons";
import { views } from "./Views";
import { useSessionService } from "@realmocean/services";
import { DynoDialog } from "./dialogs/DynoDialog";
import { ListStatusesDialog } from "./dialogs/ListStatusesDialog";

export class MyTestController extends UIFormController {
    @State()
    private initializing: boolean;

    public LoadView() {
        const navigate = useNavigate();


        const { applet_id, opa_name, view_id } = useParams();
        //  const zstack =  ZStack({"alignment":"cTopLeading"} as any);
        const { app_name, workspace_id, folder_id, item_id, parent, scope_id } = useParams()
        //this.InvalidateQuerie('space-folder-items')

        const { gql, _mutation } = useProtocol(WorkProtocol);


        const { data: { scope, applet }, isLoading: isLoading, invalidateQuery } = gql`
        scope(id: ${scope_id}){
            id
            broker
            initialized
        }

        applet(id: ${applet_id}){
            id
            name
            folder {
                id
                name
            }
            views {
                id
                view
                title
            }
        }

        `

        //  return Text(JSON.stringify(applet))

        const { mutate: updateScope, isLoading: isScopeUpdating } = _mutation`update_scope {
           id
        }`



        const { mutate: createView } = _mutation`create_view {
            id
            title
        }`

        const { _query: query, _mutation: mut, _service } = useProtocol(TaskProtocol);



        const { mutate: createStage } = mut`
        create_stage {
            id
            title
        }`

        const { mutate: initScope } = mut`
        initialize_scope {
            success
        }`

        const selectedIndex = applet?.views?.findIndex(view => view.id === view_id);

        const [editingView, setEditingView] = useState(null)


        if (isLoading) {
            return Spinner();
        } else if (!scope.initialized) {
            if (!this.initializing) {

                this.initializing = true;

                initScope({
                    scope_id: scope_id
                }, {
                    onSuccess: () => {
                        updateScope({
                            id: scope_id,
                            initialized: true
                        }, {
                            onSuccess: () => {
                                invalidateQuery();
                                // navigate(`/app/com.tuvalsoft.app.workbench/workspace/${workspace_id}/folder/${folder_id}/applet/${applet_id}/scope/${scope_id}`)
                            }
                        })
                    }
                })

            }
            return (
                Text('Scope initializing...')
            )
        } else if (scope.initialized) {
            return (
                (view_id == null && applet.views.length > 0) ?
                    UINavigate(`/app/${getAppFullName()}/workspace/${workspace_id}/folder/${folder_id}/applet/${applet_id}/scope/${scope_id}/view/${applet.views[0].id}`) :
                    BrokerContext(scope.broker)(() =>
                        HStack({ alignment: cTopLeading })(
                            VStack({ alignment: cTopLeading })(

                                HStack({ alignment: cLeading })(
                                    HStack(
                                        UIWidget('com.tuvalsoft.widget.applet-name')
                                            .config({
                                                applet_id, scope_id,
                                                menu: [
                                                    {
                                                        title: 'List Settings',
                                                        type: 'Title'
                                                    },
                                                    {
                                                        title: 'List statuses',
                                                        icon: SvgIcon('svg-sprite-global__status'),

                                                        onClick: () => {
                                                            DynoDialog.Show(ListStatusesDialog)
                                                        }

                                                    },
                                                ]
                                            })
                                    ).width(),


                                    HStack({ alignment: cLeading })(
                                        UIWidget('com.tuvalsoft.widget.views-tab')
                                            .config({
                                                tenant_id: useSessionService().TenantId,
                                                app_id: getAppFullName(),
                                                account_id: useSessionService().AccountId,
                                                workspace_id,
                                                folder_id,
                                                applet_id,
                                                scope_id,
                                                view_id,
                                                allViews: views
                                            })
                                    ),
                                    Spacer(),
                                    HStack(

                                    ).width(50)

                                )
                                    .allHeight(51)
                                    .borderBottom('solid 1px #E8EAED'),
                                UIRouteOutlet().width('100%').height('100%')
                            ).background('white')
                        ).background('#FAFBFC')
                    )

            )
        }

    }

}