import { Spinner, UIController, UIRoute, UIRoutes, UIView, UIViewBuilder, VStack, WorkProtocol, useParams, useProtocol, useState } from "@tuval/forms";
import { MyTestController } from "./AppController";
import { ViewController } from "./ViewController";


export class RouteController extends UIController {

    private routeView() {
        return (
            UIViewBuilder(() =>
                VStack(
                    UIRoutes(
                        UIRoute('/', MyTestController).children(
                            UIRoute('view/:view_id', ViewController)
                        )
                    )
                )
                    .background('var(--primary-background-color)')
            )


        )
    }
    public LoadView(): UIView {

        const { scope_id } = useParams();

        const { gql, _mutation } = useProtocol(WorkProtocol);



        const { data: { scope }, isLoading: isLoading, invalidateQuery } = gql`
        
        scope(id: ${scope_id}){
            id
            broker
            initialized
        }
        `

        //  return Text(JSON.stringify(applet))

        const { mutate: updateScope, isSuccess, isLoading: isScopeUpdating } = _mutation`update_scope {
           id
        }`


        return this.routeView();




    }
}